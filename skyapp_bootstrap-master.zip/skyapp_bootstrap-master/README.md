SKYAPP HTML5 TEMPLATE
================

This is a Bootstrap HTML5 template with SASS

You can change color scheme and fonts in the scss/base/_variables.scss file

Mixins are located in scss/base/_mixins.scss
